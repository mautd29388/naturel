<?php 
$ids = explode(',', $atts['ids']);
?>
<div class="gallery-about <?php echo esc_attr($atts['class_name'])?>">
	<div class="gallery-flickity">
		<?php foreach ( $ids as $id ) { ?>
		<div class="gallery-cell animated" data-animate="fadeInRight animation">
			<?php echo wp_get_attachment_image($id, 'fullsize'); ?>
		</div>
		<?php } ?>
	</div>
</div>