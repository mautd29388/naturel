<?php
class mTheme_Shortcode {
	
	public static $int = 0;
	public function __construct() {
		
		// Define shortcodes
		$shortcodes = array (
				'mTheme_latest' => __CLASS__ . '::latest',
				'mTheme_services' => __CLASS__ . '::services',
				'mTheme_menu' => __CLASS__ . '::menu',
				'mTheme_galleries' => __CLASS__ . '::galleries',
				'mTheme_slider' => __CLASS__ . '::slider',
				'mTheme_maps' => __CLASS__ . '::maps',
		);
		
		foreach ( $shortcodes as $shortcode => $function ) {
			add_shortcode ( apply_filters ( "{$shortcode}_shortcode_tag", $shortcode ), $function );
		}
		
		add_filter ( 'the_content', array ( $this, 'shortcode_empty_paragraph_fix' ) );
		add_action ( 'vc_before_init', array ( $this, 'add_shortcodes_to_vc' ) );
		
		$plugin_dir_url = untrailingslashit ( plugin_dir_url ( __FILE__ ) );
		add_shortcode_param ( 'categories', array ( $this, 'add_shortcode_param_categories' ), $plugin_dir_url.'/assets/js/vc_extend.js' );
	}
	
	public static function mTheme_get_template_part($slug, $name = '') {
		$template_path = untrailingslashit ( plugin_dir_path ( __FILE__ ) );
		
		$template = '';
		
		$name = ( string ) $name;
		if ('' !== $name) {
			$template = $template_path . "/contents/{$slug}-{$name}.php";
		} else
			$template = $template_path . "/contents/{$slug}.php";
		
		return $template;
	}
	public static function shortcode_empty_paragraph_fix($content) {
		$array = array (
				'<p>[' => '[',
				']</p>' => ']',
				']<br />' => ']' 
		);
		
		$content = strtr ( $content, $array );
		
		return $content;
	}
	public static function services($atts) {
		
		$atts = shortcode_atts ( array (
				'posts_per_page' => '-1',
				'orderby' => 'menu_order',
				'order' => 'ASC',
				'class_name' => ''
		), $atts );
		
		$args = array(
				'post_type' => 'mmenu',
				'posts_per_page' => $atts['posts_per_page'],
				'post_status' => 'publish',
				'orderby' => $atts['orderby'],
				'order' => $atts['order'],
		);
		
		$query = new WP_Query( $args );
		
		ob_start();
		
		$template = self::mTheme_get_template_part ( 'content', 'services' );
		if ( file_exists("{$template}") ) {
			require "{$template}";
		}
		
		wp_reset_postdata();
		
		return ob_get_clean ();
	}
	
	public static function latest($atts){
		
		$atts = shortcode_atts ( array (
				'categories' => '',
				'posts_per_page' => '4',
				'class_name' => ''
		), $atts );
		
		$args = array(
				'posts_per_page'    => $atts['posts_per_page'],
				'post_status'       => 'publish',
				'cat' 			=> $atts['categories']
		);
		
		$posts = wp_get_recent_posts( $args ); 
		
		ob_start();
		
		$template = self::mTheme_get_template_part ( 'content', 'latest' );
		if ( file_exists("{$template}") ) {
			require "{$template}";
		}
		
		return ob_get_clean ();		
	}
	
	public static function galleries($atts) {

		self::$int++;
		
		$int = self::$int;
		
		$atts = shortcode_atts ( array (
				'posts_per_page' => '6',
				'class_name' => '',
				'styles' => 'style-v1',
				'single' => 'expanding',
				'cols' => '2'
		), $atts );
		
		$args = array(
				'post_type' => 'mgallery',
				'posts_per_page' => $atts['posts_per_page'],
				'post_status' => 'publish'
		);
		
		$query = new WP_Query( $args );
		
		ob_start();
		
		if ( $atts['styles'] == 'style-v1' || $atts['styles'] == 'style-v3' ) {
			$template = self::mTheme_get_template_part ( 'content', 'galleries' );
		} else {
			$single = $atts['single'];
			$columns = $atts['cols'];
			
			$template = m_retation_get_template_part ( 'content', 'gallery' );
		}
		if ( file_exists("{$template}") ) {
			require "{$template}";
		}
		
		wp_reset_postdata();
		
		return ob_get_clean ();
	}
	public static function menu($atts) {
	
		$atts = shortcode_atts ( array (
				'class_name' => '',
		), $atts );
	
		$args = array(
				'post_type' => 'mmenu',
				'posts_per_page' => '-1',
				'post_status' => 'publish',
				'orderby' => 'menu_order',
				'order' => 'ASC',
		);
	
		$query = new WP_Query( $args );
	
		ob_start();
				
		$template = m_retation_get_template_part ( 'content', 'menu' );
		if ( file_exists("{$template}") ) {
			require "{$template}";
		}
	
		wp_reset_postdata();
	
		return ob_get_clean ();
	}
	public static function slider($atts) {
		
		$atts = shortcode_atts ( array (
				'ids' => '',
				'class_name' => '',
		), $atts );
		
		ob_start();
		
		if ( isset($atts['ids']) && !empty($atts['ids']) ) {
			$template = $template = self::mTheme_get_template_part ( 'content', 'slider' );
			if ( file_exists("{$template}") ) {
				require "{$template}";
			}
		}
		return ob_get_clean ();		
	}
	public static function maps($atts, $content = '') {
		$atts = shortcode_atts ( array (
				'LatLng' => '51.5042389, -0.1061977',
				'zoom' => 13,
				'icon' => trailingslashit( get_template_directory_uri () ) . 'assets/imgs/icon-map.png',
				'class_name' => '',
		), $atts );
		
		if ( !empty($content) )
			$content = '<p>Email: noreply@gmail.com<br>Phone: +800 - 568 - 8989<br>96 Isabella ST, London, SE 1 8DD</p>';
		
		wp_enqueue_script('google-maps-js');
		wp_enqueue_script('maps-js');
		
		$mtheme_maps = array();
		$mtheme_maps['LatLng'] = $atts['LatLng'];
		$mtheme_maps['desc_contact'] = $content;
		$mtheme_maps['zoom'] = $atts['zoom'];
		$mtheme_maps['icon'] = $atts['icon'];
		
		wp_localize_script ( 'maps-js', 'mtheme_maps', $mtheme_maps );
		
		ob_start();
		
		echo '<div class="maps '. $atts['class_name'] .'"><div id="map-canvas"></div></div>';
		
		return ob_get_clean ();
	}
	
	/**
	 * Add Shortcodes to Visual Composer
	 */
	public static function add_shortcodes_to_vc() {
		
		 vc_map ( array (
		 		'name' => __ ( 'mTheme Services', 'mTheme' ),
		 		'base' => 'mTheme_services',
		 		'category' => __ ( 'mTheme', 'mTheme' ),
		 		'icon' => 'vc_element-icon icon-wpb-atm',
		 		"params" => array (
		 				array (
		 						'type' => 'textfield',
		 						'heading' => __ ( 'Extra class name', 'mTheme' ),
		 						'param_name' => 'class_name'
		 				)
		 		)
		 ) ); 
		 
		 vc_map ( array (
		 		'name' => __ ( 'mTheme Latest', 'mTheme' ),
		 		'base' => 'mTheme_latest',
		 		'category' => __ ( 'mTheme', 'mTheme' ),
		 		'icon' => 'vc_element-icon icon-wpb-atm',
		 		"params" => array (
		 				array (
		 						'type' => 'categories',
		 						'heading' => __ ( 'Categories', 'mTheme' ),
		 						'param_name' => 'categories',
		 				),
		 				array (
		 						'type' => 'textfield',
		 						'heading' => __ ( 'Number of posts to show', 'mTheme' ),
		 						'param_name' => 'posts_per_page',
		 						'value' => '4',
		 				),
		 				array (
		 						'type' => 'textfield',
		 						'heading' => __ ( 'Extra class name', 'mTheme' ),
		 						'param_name' => 'class_name'
		 				)
		 		)
		 ) );
		 
		 vc_map ( array (
		 		'name' => __ ( 'mTheme Galleries', 'mTheme' ),
		 		'base' => 'mTheme_galleries',
		 		'category' => __ ( 'mTheme', 'mTheme' ),
		 		'icon' => 'vc_element-icon icon-wpb-atm',
		 		"params" => array (
		 				array (
		 						'type' => 'dropdown',
		 						'heading' => __ ( 'Styles', 'mTheme' ),
		 						'param_name' => 'styles',
		 						'value' => array(
		 								__ ( 'Style v1', 'mTheme' ) => 'style-v1',
		 								__ ( 'Style v2', 'mTheme' ) => 'style-v2',
		 								__ ( 'Style v3', 'mTheme' ) => 'style-v3',
		 						),
		 						'description' => __ ( '', 'mTheme' ),
		 				),
		 				array (
		 						'type' => 'dropdown',
		 						'heading' => __ ( 'Single Display', 'mTheme' ),
		 						'param_name' => 'single',
		 						'value' => array(
		 								__ ( 'Expanding', 'mTheme' ) => 'expanding',
		 								__ ( 'Popup', 'mTheme' ) => 'popup',
		 						),
		 						'description' => __ ( '', 'mTheme' ),
		 						'dependency' => array(
		 								'element' => 'styles',
		 								'value' => array('style-v2'),
		 						)
		 				),
		 				array (
		 						'type' => 'dropdown',
		 						'heading' => __ ( 'Columns', 'mTheme' ),
		 						'param_name' => 'cols',
		 						'value' => array(
		 								__ ( 'Two', 'mTheme' ) => '2',
		 								__ ( 'Three', 'mTheme' ) => '3',
		 								__ ( 'Four', 'mTheme' ) => '4',
		 						),
		 						'description' => __ ( '', 'mTheme' ),
		 						'dependency' => array(
		 								'element' => 'styles',
		 								'value' => array('style-v2'),
		 						)
		 				),
		 				array (
		 						'type' => 'textfield',
		 						'heading' => __ ( 'Number of posts to show', 'mTheme' ),
		 						'param_name' => 'posts_per_page',
		 						'value' => '6',
		 				),
		 				array (
		 						'type' => 'textfield',
		 						'heading' => __ ( 'Extra class name', 'mTheme' ),
		 						'param_name' => 'class_name'
		 				)
		 		)
		 ) );
		 
		 vc_map ( array (
		 		'name' => __ ( 'mTheme Menu', 'mTheme' ),
		 		'base' => 'mTheme_menu',
		 		'category' => __ ( 'mTheme', 'mTheme' ),
		 		'icon' => 'vc_element-icon icon-wpb-atm',
		 		"params" => array (
		 				array (
		 						'type' => 'textfield',
		 						'heading' => __ ( 'Extra class name', 'mTheme' ),
		 						'param_name' => 'class_name'
		 				)
		 		)
		 ) );
		 
		 vc_map ( array (
		 		'name' => __ ( 'mTheme Slider', 'mTheme' ),
		 		'base' => 'mTheme_slider',
		 		'category' => __ ( 'mTheme', 'mTheme' ),
		 		'icon' => 'vc_element-icon icon-wpb-atm',
		 		"params" => array (
		 				array (
		 						'type' => 'attach_images',
		 						'heading' => __ ( 'Images', 'mTheme' ),
		 						'param_name' => 'ids'
		 				),
		 				array (
		 						'type' => 'textfield',
		 						'heading' => __ ( 'Extra class name', 'mTheme' ),
		 						'param_name' => 'class_name'
		 				)
		 		)
		 ) );
		 
		 vc_map ( array (
		 		'name' => __ ( 'mTheme Maps', 'mTheme' ),
		 		'base' => 'mTheme_maps',
		 		'category' => __ ( 'mTheme', 'mTheme' ),
		 		'icon' => 'vc_element-icon icon-wpb-atm',
		 		"params" => array (
		 				array (
		 						'type' => 'textfield',
		 						'heading' => __ ( 'Longitude and latitude of the map center', 'mTheme' ),
		 						'param_name' => 'LatLng',
		 						'value' => '51.5042389, -0.1061977'
		 				),
		 				array (
		 						'type' => 'textarea',
		 						'heading' => __ ( 'Locations Description', 'mTheme' ),
		 						'param_name' => 'content',
		 						'value' => '<p>Email: noreply@gmail.com<br>Phone: +800 - 568 - 8989<br>96 Isabella ST, London, SE 1 8DD</p>'
		 				),
		 				array (
		 						'type' => 'textfield',
		 						'heading' => __ ( 'Zoom', 'mTheme' ),
		 						'param_name' => 'zoom',
		 						'value' => '13'
		 				),
		 				array (
		 						'type' => 'textfield',
		 						'heading' => __ ( 'Icon', 'mTheme' ),
		 						'param_name' => 'icon',
		 				),
		 				array (
		 						'type' => 'textfield',
		 						'heading' => __ ( 'Extra class name', 'mTheme' ),
		 						'param_name' => 'class_name'
		 				)
		 		)
		 ) );
	}
	
	public static function add_shortcode_param_categories( $settings, $value ) {
	    $output = '';
	    $categories = get_categories();
	    foreach ( $categories as $category ) {
	    	$checked = "";
	    		if ( in_array( $category->term_id, explode( ",", $value ) ) ) {
	    			$checked = ' checked';
	    		}
	    		$output .= ' <label class="vc_checkbox-label"><input id="'
	    				. $settings['param_name'] . '-' . $category->term_id . '" value="'
	    				. $category->term_id . '" class="wpb_vc_param_value '
	    				. $settings['param_name']
	    				. ' ' . $settings['type']
	    				. '" type="checkbox" name="'
	    				. $settings['param_name'] . '"' . $checked . '> '
	    				. $category->name . '</label>';
	    }
	    
	    return $output;
	}
}

new mTheme_Shortcode ();