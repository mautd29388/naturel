<div class="<?php echo isset($atts['class_name']) ? esc_attr($atts['class_name']) : ''; ?>">
	<ul class="posts-list">
	<?php $i = 0;
	foreach ( $posts as $post ) { 
		$i++; ?>
		<li>
			<?php if ( has_post_thumbnail($post["ID"]) && $i%2 != 0 ) { ?>
			<figure>
				<a href="<?php echo get_permalink($post["ID"]); ?>"><?php echo get_the_post_thumbnail($post["ID"], 'thumbnail'); ?></a>
			</figure>
			<?php } ?>
			<aside>
				<h4 class="title">
					<a href="<?php echo get_permalink($post["ID"]); ?>"><?php echo get_the_title($post["ID"]); ?></a>
				</h4>
				<div class="entry-meta">
					Post by <?php the_author_posts_link(); ?> / <?php the_category(', ', '', $post["ID"]); ?> / <?php echo get_comments_number_text(); ?>
				</div>
				<p><?php echo m_retation_trim(apply_filters( 'get_the_excerpt', $post['post_excerpt'] ), 20); ?></p>
			</aside>
			<?php if ( has_post_thumbnail($post["ID"]) && $i%2 == 0 ) { ?>
			<figure>
				<a href="<?php echo get_permalink($post["ID"]); ?>"><?php echo get_the_post_thumbnail($post["ID"], 'thumbnail'); ?></a>
			</figure>
			<?php } ?>
		</li>
	<?php } ?>
	</ul>
</div>