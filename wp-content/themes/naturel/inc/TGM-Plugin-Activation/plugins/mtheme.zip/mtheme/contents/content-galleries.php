
<?php if ( $atts['styles'] == 'style-v3' ) { ?>
<div class="section widget-gallery <?php echo isset($atts['class_name']) ? esc_attr($atts['class_name']) : ''; ?>">
	<div class="widget-gallery-flickity">
	<?php 
	$i = 0;
	while ( $query->have_posts () ) : $query->the_post (); ?>
		
		<?php if ( has_post_thumbnail() ) { ?>
		<div class="gallery-cell">
			<figure>
				<?php the_post_thumbnail('thumbnail', array('class' => 'animated', 'data-animate' => 'zoomIn animation')) ?>
				<figcaption>
					<a class="gallery-ajax" href="#" data-url="<?php echo get_permalink(get_the_ID()); ?>" title="<?php the_title(); ?>" data-toggle="modal" data-target="#galleryModal-<?php echo esc_attr($int) .'-'. esc_attr($i); ?>" data-single="popup"></a>
				</figcaption>
			</figure>
		</div>
		<?php 
		$i++;
		} ?>
	<?php endwhile;  ?>
	</div>
</div>	
<?php } else { ?>
<div class="section widget-gallery <?php echo isset($atts['class_name']) ? esc_attr($atts['class_name']) : ''; ?>">
	<ul>
	<?php 
	$i = 0;
	while ( $query->have_posts () ) : $query->the_post (); ?>
		
		<?php if ( has_post_thumbnail() ) { ?>
		<li>
			<figure>
				<?php the_post_thumbnail('thumbnail', array('class' => 'animated', 'data-animate' => 'zoomIn animation')) ?>
				<figcaption>
					<a class="gallery-ajax" href="#" data-url="<?php echo get_permalink(get_the_ID()); ?>" data-toggle="modal" data-target="#galleryModal-<?php echo esc_attr($int) .'-'. esc_attr($i); ?>" data-single="popup"></a>
				</figcaption>
			</figure>
		</li>
		<?php 
		$i++;
		} ?>
	<?php endwhile;  ?>
	</ul>
</div>
<?php } ?>
<?php for ( $j = 0; $j < $i; $j++ ) { ?>
<div class="modal" id="galleryModal-<?php echo esc_attr($int) .'-'. esc_attr($j); ?>">
	<div class="modal-content">

		<div class="modal-header">
			<div class="container">
				<button aria-label="Close" data-dismiss="modal" class="close"
					type="button">
					<span aria-hidden="true" class="fa fa-close"></span>
				</button>
			</div>
		</div>
		<div class="modal-body"></div>

	</div>
	<!-- /.modal-content -->
</div>
<?php } ?>
