<?php
class mTheme_Post_Type {
	public function __construct() {
		
		add_action ( 'init', array ( $this, 'mTheme_post_type_menus' ) );
		add_action ( 'init', array ( $this, 'mTheme_post_type_galleries' ) );
	}
	
	/**
	 * Menus
	 */
	public function mTheme_post_type_menus() {
		$labels = array (
				'name' => __ ( 'Menu', 'mTheme' ),
				'singular_name' => __ ( 'Menu', 'mTheme' ),
				'add_new' => __ ( 'Add New', 'mTheme' ),
				'add_new_item' => __ ( 'Add New', 'mTheme' ),
				'edit_item' => __ ( 'Edit', 'mTheme' ),
				'new_item' => __ ( 'New', 'mTheme' ),
				'view_item' => __ ( 'View', 'mTheme' ),
				'search_items' => __ ( 'Search', 'mTheme' ),
				'not_found' => __ ( 'No post found', 'mTheme' ),
				'not_found_in_trash' => __ ( 'No post found in Trash', 'mTheme' ),
				'parent_item_colon' => '',
				'menu_name' => _x ( 'Menus', 'Admin menu name', 'mTheme' ) 
		);
		
		$args = array (
				'labels' => $labels,
				'public' => true,
				'exclude_from_search' => true,
				'publicly_queryable' => true,
				'show_ui' => true,
				'show_in_nav_menus' => false,
				'query_var' => true,
				'rewrite' => array (
						'slug' => 'type-menu' 
				),
				'capability_type' => 'post',
				'has_archive' => true,
				'hierarchical' => false,
				'menu_position' => null,
				'menu_icon' => 'dashicons-store',
				'supports' => array (
						'title',
						'editor',
						//'author',
						//'excerpt',
						'thumbnail',
						'page-attributes'
				) 
		);
		
		register_post_type ( 'mmenu', $args );
		
	} // End Menus
	
	
	/**
	 * Galleries
	 */
	public function mTheme_post_type_galleries() {
		$labels = array (
				'name' => __ ( 'Gallery', 'mTheme' ),
				'singular_name' => __ ( 'Gallery', 'mTheme' ),
				'add_new' => __ ( 'Add New', 'mTheme' ),
				'add_new_item' => __ ( 'Add New', 'mTheme' ),
				'edit_item' => __ ( 'Edit', 'mTheme' ),
				'new_item' => __ ( 'New', 'mTheme' ),
				'view_item' => __ ( 'View', 'mTheme' ),
				'search_items' => __ ( 'Search', 'mTheme' ),
				'not_found' => __ ( 'No post found', 'mTheme' ),
				'not_found_in_trash' => __ ( 'No post found in Trash', 'mTheme' ),
				'parent_item_colon' => '',
				'menu_name' => _x ( 'Galleries', 'Admin menu name', 'mTheme' )
		);
	
		$args = array (
				'labels' => $labels,
				'public' => true,
				'exclude_from_search' => true,
				'publicly_queryable' => true,
				'show_ui' => true,
				'show_in_nav_menus' => false,
				'query_var' => true,
				'rewrite' => array (
						'slug' => 'type-galleries'
				),
				'capability_type' => 'post',
				'has_archive' => true,
				'hierarchical' => false,
				'menu_position' => null,
				'menu_icon' => 'dashicons-images-alt2',
				'supports' => array (
						'title',
						'editor',
						//'author',
						//'excerpt',
						'thumbnail'
				)
		);
	
		register_post_type ( 'mgallery', $args );
		
		// Initialize Category Taxonomy Labels
		$labels = array (
				'name' => __ ( 'Gallery Categories', 'mTheme' ),
				'singular_name' => __ ( 'Category', 'mTheme' ),
				'search_items' => __ ( 'Search Types', 'mTheme' ),
				'all_items' => __ ( 'All Categories', 'mTheme' ),
				'parent_item' => __ ( 'Parent Category', 'mTheme' ),
				'parent_item_colon' => __ ( 'Parent Category:', 'mTheme' ),
				'edit_item' => __ ( 'Edit Category', 'mTheme' ),
				'update_item' => __ ( 'Update Category', 'mTheme' ),
				'add_new_item' => __ ( 'Add New Category', 'mTheme' ),
				'new_item_name' => __ ( 'New Category Name', 'mTheme' ),
				'menu_name' => _x ( 'Categories', 'Admin menu name', 'mTheme' )
		);
		
		register_taxonomy ( 'mgallery_cat', array (
				'mgallery'
		), array (
				'hierarchical' => true,
				'labels' => $labels,
				'show_ui' => true,
				'show_in_nav_menus' => false,
				'query_var' => true,
				'rewrite' => array (
						'slug' => 'gallery-cat'
				)
		) ); // End Category
	
	} // End Galleries
	
}

new mTheme_Post_Type ();