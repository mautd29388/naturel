(function ( $ ) {
	var vc_activeMce;

	vc.atts.categories = {
		parse: function ( param ) {
			var categories_arr = [],
				new_value = '';
			$( 'input[name=' + param.param_name + ']', this.content() ).each( function () {
				var self = $( this );
				if ( this.checked ) {
					categories_arr.push( self.attr( "value" ) );
				}
			} );
			if ( 0 < categories_arr.length ) {
				new_value = categories_arr.join( ',' );
			}
			return new_value;
		}
	};
})( window.jQuery );