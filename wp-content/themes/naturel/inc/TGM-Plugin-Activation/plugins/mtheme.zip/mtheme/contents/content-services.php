
<ul id="services-item" class="<?php echo isset($atts['class_name']) ? esc_attr($atts['class_name']) : ''; ?>">
<?php while ( $query->have_posts () ) : $query->the_post (); ?>
	<li class="service">
		<aside>
			<div class="service-inner">
				<h3>
					<a href="<?php echo get_post_type_archive_link('mmenu'); ?>#coffee" title="<?php the_title(); ?>"><?php the_title(); ?></a>
				</h3>
				<div class="service-item-content"><?php the_content(); ?></div>
			</div>
		</aside>
		<em class="animated animation infinite bullets"></em>
	</li>
<?php endwhile;  ?>
</ul>